def multiply(x, y):
    return x * y
